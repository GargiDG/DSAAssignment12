class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        next = null;
    }
}

class LinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void deleteMiddle() {
        if (head == null || head.next == null) {
            head = null; // Empty or single node list, return null
            return;
        }

        Node slow = head;
        Node fast = head;
        Node prev = null;

        while (fast != null && fast.next != null) {
            fast = fast.next.next;
            prev = slow;
            slow = slow.next;
        }

        prev.next = slow.next;
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
public class DSA12Q1 {

	public static void main(String[] args) {
		LinkedList linkedList = new LinkedList();
        linkedList.insert(2);
        linkedList.insert(4);
        linkedList.insert(6);
        linkedList.insert(7);
        linkedList.insert(5);
        linkedList.insert(1);
        System.out.println("Input:");
        linkedList.display();

        linkedList.deleteMiddle();

        System.out.println("Output:");
        linkedList.display();

	}

}
