
class Node {
    char data;
    Node next;

    public Node(char data) {
        this.data = data;
        next = null;
    }
}

class LinkedList {
    Node head;

    public void insert(char data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public boolean isPalindrome() {
        if (head == null || head.next == null) {
            return true; // An empty list or a single node list is considered a palindrome
        }

        Node slow = head;
        Node fast = head;

        // Move the fast pointer to the middle of the list
        while (fast.next != null && fast.next.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }

        Node secondHalf = slow.next;
        slow.next = null; // Break the list into two halves

        // Reverse the second half of the list
        Node prev = null;
        Node current = secondHalf;
        Node next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        secondHalf = prev;

        // Compare the first half and reversed second half
        Node p1 = head;
        Node p2 = secondHalf;
        while (p1 != null && p2 != null) {
            if (p1.data != p2.data) {
                return false; // Characters do not match, not a palindrome
            }
            p1 = p1.next;
            p2 = p2.next;
        }

        return true; // All characters match, it is a palindrome
    }
}

public class DSA12Q4 {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.insert('C');
        linkedList.insert('O');
        linkedList.insert('D');
        linkedList.insert('E');
        

        boolean isPalindrome = linkedList.isPalindrome();
        System.out.println(isPalindrome);
    }
}
