
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        next = null;
    }
}

class LinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void retainMDeleteN(int M, int N) {
        if (head == null || M <= 0 || N <= 0) {
            return; // Invalid input or empty list
        }

        Node current = head;
        Node prev = null;

        while (current != null) {
            // Traverse M nodes
            for (int i = 1; i < M && current != null; i++) {
                current = current.next;
            }

            // If there are no more nodes to traverse, break the loop
            if (current == null) {
                break;
            }

            // Delete N nodes
            Node temp = current.next;
            for (int i = 0; i < N && temp != null; i++) {
                temp = temp.next;
            }
            current.next = temp;

            // Move to the next Mth node
            current = temp;
        }
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class DSA12Q6 {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.insert(1);
        linkedList.insert(2);
        linkedList.insert(3);
        linkedList.insert(4);
        linkedList.insert(5);
        linkedList.insert(6);
        linkedList.insert(7);
        linkedList.insert(8);

        int M = 2;
        int N = 2;

        System.out.println("Input:");
        linkedList.display();

        linkedList.retainMDeleteN(M, N);

        System.out.println("Output:");
        linkedList.display();
    }
}
