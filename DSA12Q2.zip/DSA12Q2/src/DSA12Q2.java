
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        next = null;
    }
}

class LinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public boolean hasLoop() {
        Node slow = head;
        Node fast = head;

        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;

            if (slow == fast) {
                return true; // Loop detected
            }
        }

        return false; // No loop found
    }
}



public class DSA12Q2 {
	public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.insert(1);
        //linkedList.insert(8);
        linkedList.insert(3);
        linkedList.insert(4);

        // Create a loop by connecting the tail to the second node
        linkedList.head.next.next.next = linkedList.head.next;
        
        boolean hasLoop = linkedList.hasLoop();
        System.out.println(hasLoop);
	}
}
