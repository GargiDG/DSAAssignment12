
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        next = null;
    }
}

class LinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void mergeAlternate(LinkedList list2) {
        if (head == null || list2.head == null) {
            return;
        }

        Node current1 = head;
        Node current2 = list2.head;
        Node next1, next2;

        while (current1 != null && current2 != null) {
            // Save the next pointers
            next1 = current1.next;
            next2 = current2.next;

            // Make current2's node as current1's next
            current2.next = next1;
            current1.next = current2;

            // Move current1 and current2 to their next nodes
            current1 = next1;
            current2 = next2;
        }

        // Set the head of list2 to null
        list2.head = null;
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class DSA12Q7 {
    public static void main(String[] args) {
        LinkedList list1 = new LinkedList();
        list1.insert(5);
        list1.insert(7);
        list1.insert(17);
        list1.insert(13);
        list1.insert(11);

        LinkedList list2 = new LinkedList();
        list2.insert(12);
        list2.insert(10);
        list2.insert(2);
        list2.insert(4);
        list2.insert(6);

        System.out.println("Before merging:");
        System.out.print("List1: ");
        list1.display();
        System.out.print("List2: ");
        list2.display();

        list1.mergeAlternate(list2);

        System.out.println("After merging:");
        System.out.print("List1: ");
        list1.display();
        System.out.print("List2: ");
        list2.display();
    }
}
