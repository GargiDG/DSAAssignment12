class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        next = null;
    }
}

class LinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public int findNthFromEnd(int n) {
        if (head == null) {
            throw new IllegalArgumentException("The linked list is empty.");
        }

        Node fast = head;
        Node slow = head;

        // Move the fast pointer to the Nth node from the start
        for (int i = 0; i < n; i++) {
        	  // If fast is null, it means N is equal to or greater than the number of nodes in the linked list
            if (fast == null) {
                return -1;
            }
            else
            fast = fast.next;
        }

      

        // Move both pointers simultaneously until the fast pointer reaches the end
        while (fast != null) {
            fast = fast.next;
            slow = slow.next;
        }

        return slow.data;
    }
}

public class DSA12Q3 {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.insert(1);
        linkedList.insert(2);
        linkedList.insert(3);
        linkedList.insert(4);
        linkedList.insert(5);
        linkedList.insert(6);
        linkedList.insert(7);
        linkedList.insert(8);
        linkedList.insert(9);

        int n = 2;
        int nthFromEnd = linkedList.findNthFromEnd(n);
        System.out.println(nthFromEnd);
    }
}
